Make sure to extract all documents in the same folder. 
Run "Script"
Figure 1: Q1
Figure 2: Concentration evolution vs. time of MAPKKK system
Figure 3: Switch like response without feedback
Figure 4: Oscillatory response at v1max=2.5nm/s
Figure 5: Oscillatory response comparison at v1max=1,0.5,0.2,0.1 nm/s