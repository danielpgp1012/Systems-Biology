To run program, just run Script
Ensure that you load the path dependencies. 
Use to grade Q1, Q2, Q4
Question 3 is solved, but the results in the report correspond to the Python results. 
Ensure that you have all the files of the zipped folder as some workspaces were saved to run the program faster.
