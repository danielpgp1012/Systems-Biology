Run Script. 
Ensure you have model in the same folder. 
FIGURES:
For the figures to appear in the proper way, you will need to edit the function 'phenotypePhasePlane' 
and remove the number after 'figure' in lines 84, 87 and 89. This command prevents the function from overwriting 
already existing figures in the workspace. 
 